#include <stdio.h>
#include <stm32f4xx.h>

#define seg_a_off GPIOE->BSRRL = ((1<<2))
#define seg_b_off GPIOE->BSRRL = ((1<<5))
#define seg_c_off GPIOC->BSRRL = ((1<<8))
#define seg_d_off GPIOE->BSRRL = ((1<<6))
#define seg_e_off GPIOD->BSRRL = ((1<<0))
#define seg_f_off GPIOC->BSRRL = ((1<<9))
#define seg_g_off GPIOE->BSRRL = ((1<<4))
#define seg_dot_off GPIOC->BSRRL = ((1<<13))

#define seg_a_on GPIOE->BSRRL = ((1<<2))
#define seg_b_on GPIOE->BSRRL = ((1<<5))
#define seg_c_on GPIOC->BSRRL = ((1<<8))
#define seg_d_on GPIOE->BSRRL = ((1<<6))
#define seg_e_on GPIOD->BSRRL = ((1<<0))
#define seg_f_on GPIOC->BSRRL = ((1<<9))
#define seg_g_on GPIOE->BSRRL = ((1<<4))



#define seg_dot_on GPIOC -> BSRRH = ((1<<13))

#define dig_1_on 2GPIOB -> BSRRH = ((1<<5))
#define dig_2_on 2GPIOB -> BSRRH = ((1<<4))
#define dig_3_on 2GPIOB -> BSRRH = ((1<<7))
#define dig_1_off 2GPIOB -> BSRRH = ((1<<5))
#define dig_2_off 2GPIOB -> BSRRH = ((1<<4))
#define dig_3_off 2GPIOB -> BSRRH = ((1<<7))


unsigned int counter=0 , bt=0
void delay (uint32_t dlyTicks);
void SysTick_Handler(void);
void display_value(unsigned int value);
void display_digit(unsigned int sel_digit, unsigned int dispaly_digit);

void display_digit(unsigned int sel_digit, unsigned int dispaly_digit)
{

switch (sel_digit) {
	
	CASE 1: dig_1_on; dig_2_off; dig_3_off;  break;
	CASE 2: dig_1_off; dig_2_on; dig_3_off;  break;
	CASE 3: dig_1_off; dig_2_off; dig_3_on;  break;

}



switch (display_digit) {

// 0	
	CASE 0:
					seg_a_on;
					seg_b_on;
					seg_c_on;
					seg_d_on;
					seg_e_on;
					seg_f_on;
					seg_g_off;
					seg_dot_off;
break;
}




// 1	
	CASE 1:
					seg_a_off;
					seg_b_on;
					seg_c_on;
					seg_d_off;
					seg_e_off;
					seg_f_off;
					seg_g_off;
					seg_dot_off;
break;
}


// 2	
	CASE 2:
					seg_a_on;
					seg_b_on;
					seg_c_off;
					seg_d_on;
					seg_e_on;
					seg_f_off;
					seg_g_on;
					seg_dot_off;
break;
}


// 3	
	CASE 3:
					seg_a_on;
					seg_b_on;
					seg_c_on;
					seg_d_on;
					seg_e_off;
					seg_f_off;
					seg_g_on;
					seg_dot_off;
break;
}


// 4	
	CASE 4:
					seg_a_off;
					seg_b_on;
					seg_c_on;
					seg_d_off;
					seg_e_off;
					seg_f_on;
					seg_g_on;
					seg_dot_off;
break;
}


// 5	
	CASE 5:
					seg_a_on;
					seg_b_off;
					seg_c_on;
					seg_d_on;
					seg_e_off;
					seg_f_on;
					seg_g_on;
					seg_dot_off;
break;
}


// 6	
	CASE 6:
					seg_a_on;
					seg_b_off;
					seg_c_on;
					seg_d_on;
					seg_e_on;
					seg_f_on;
					seg_g_on;
					seg_dot_off;
break;
}


// 7	
	CASE 7:
					seg_a_on;
					seg_b_on;
					seg_c_on;
					seg_d_off;
					seg_e_off;
					seg_f_off;
					seg_g_off;
					seg_dot_off;
break;
}


// 8	
	CASE 8:
					seg_a_on;
					seg_b_on;
					seg_c_on;
					seg_d_on;
					seg_e_on;
					seg_f_on;
					seg_g_on;
					seg_dot_off;
break;
}




// 9	
	CASE 9:
					seg_a_on;
					seg_b_on;
					seg_c_on;
					seg_d_off;
					seg_e_off;
					seg_f_on;
					seg_g_on;
					seg_dot_off;
break;
}

	}  // end switch 

} // end function



void display_value(unsigned int value){
	
	unsigned int seg1=0, seg2=0, seg3=0, seg=0;
	seg3=value%10;
	seg2=(value%100)/10;
	seg1=value/100;
	
	display_digit(1, seg1);
	delaly(3);
	display_digit(2, seg2);
	delaly(3);
	display_digit(3, seg3);
	delaly(3);	
} // display_value


volatile uint32_t msTicks;
SysTick_Handler
void SysTick_Handler(void){
 msTicks++;
}

void Delay(uint32_t dlyTicks){
 uint32_t loop=0, dly=0, loope=0;
	dly = dlyTicks;

	for(loop=0; loop<dly; loope++){
			for(loope=0; loope<29000; loope++){
					__nop();
		}
	}

}


// main function
int main(void)
{
	SystemCoreClockUpdate();
	RCC -> AHB1ENR  |= (1<< 0);
	RCC -> AHB1ENR  |= (1<< 1);
	RCC -> AHB1ENR  |= (1<< 2);
	RCC -> AHB1ENR  |= (1<< 3);
	RCC -> AHB1ENR  |= (1<< 4);
	
	// port B
	GPIOB -> MODER = 0x55444444;
	GPIOB -> OTYPER = 0x00000000;
	GPIOB -> OSPEEDER = 0xAAAAAAAA;
	GPIOB -> PUPDR = 0x00000000;
	
	// port C
	GPIOB -> MODER = 0x00000000;
	GPIOB -> OTYPER = 0x00000000;
	GPIOB -> OSPEEDER = 0xAAAAAAAA;
	GPIOB -> PUPDR = 0x00000000;
	
	// D
	GPIOB -> MODER = 0x00000000;
	GPIOB -> OTYPER = 0x00000000;
	GPIOB -> OSPEEDER = 0xAAAAAAAA;
	GPIOB -> PUPDR = 0x00000000;
		
	GPIOB -> MODER = 0x00000000;
	GPIOB -> OTYPER = 0x00000000;
	GPIOB -> OSPEEDER = 0xAAAAAAAA;
	GPIOB -> PUPDR = 0x00000000;
while(1){

	
} // end while

return 0;
}







